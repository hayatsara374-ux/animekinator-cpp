#ifndef BINARY_TREE_H
#define BINARY_TREE_H

#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>

// Simple structure to store character data
struct AnimeCharacter {
    std::string name;
    std::string anime;
    
    AnimeCharacter() {}
    AnimeCharacter(const std::string& _name, const std::string& _anime) 
        : name(_name), anime(_anime) {}
};

class TreeNode {
private:
    std::string data;       // Question or character name
    bool isCharacter;       // True if leaf node (character), false if question
    TreeNode* left;         // "Yes" path
    TreeNode* right;        // "No" path
    std::string anime;      // For character nodes, store the anime name

public:
    // Constructors
    TreeNode() : data(""), isCharacter(false), left(nullptr), right(nullptr), anime("") {}
    
    TreeNode(const std::string& value, bool isLeaf, const std::string& animeValue = "") 
        : data(value), isCharacter(isLeaf), left(nullptr), right(nullptr), anime(animeValue) {}
    
    // Getters
    std::string getData() const { return data; }
    bool isLeaf() const { return isCharacter; }
    TreeNode* getLeft() const { return left; }
    TreeNode* getRight() const { return right; }
    std::string getAnime() const { return anime; }
    
    // Setters
    void setData(const std::string& value) { data = value; }
    void setIsLeaf(bool value) { isCharacter = value; }
    void setLeft(TreeNode* node) { left = node; }
    void setRight(TreeNode* node) { right = node; }
    void setAnime(const std::string& value) { anime = value; }
    
    // Friend class declaration
    friend class BinaryTree;
};

class BinaryTree {
private:
    TreeNode* root;
    std::vector<AnimeCharacter> characters;
    
    // Helper methods
    void destroyTree(TreeNode* node);
    void serializeHelper(TreeNode* node, std::ofstream& outFile);
    TreeNode* deserializeHelper(std::ifstream& inFile);
    
public:
    // Constructors and destructor
    BinaryTree() : root(nullptr) {}
    ~BinaryTree() { destroyTree(root); }
    
    // Basic tree operations
    bool isEmpty() const { return root == nullptr; }
    TreeNode* getRoot() const { return root; }
    
    // Tree building and modifications
    void buildNewTree(const std::string& rootQuestion, const std::string& firstCharacter, const std::string& anime = "");
    void addQuestion(TreeNode* node, const std::string& question);
    void addCharacter(TreeNode* parent, bool forYesPath, const std::string& character, const std::string& anime = "");
    void addCharacter(TreeNode* parent, const std::string& character, const std::string& anime = "");
    void updateNode(TreeNode* parent, TreeNode* oldNode, const std::string& newQuestion, 
                   const std::string& oldCharacter, const std::string& newCharacter,
                   const std::string& oldAnime, const std::string& newAnime, bool isNewCharacterYes);
    
    // CSV handling
    bool loadCharactersFromCSV(const std::string& filename);
    
    // Serialization and deserialization
    void serialize(std::ofstream& outFile);
    void deserialize(std::ifstream& inFile);
};

// Implementation of methods

void BinaryTree::destroyTree(TreeNode* node) {
    if (node == nullptr) return;
    
    // Recursively delete children
    destroyTree(node->left);
    destroyTree(node->right);
    
    // Delete the node itself
    delete node;
}

// Build a new tree with a root question and first character
void BinaryTree::buildNewTree(const std::string& rootQuestion, const std::string& firstCharacter, const std::string& anime) {
    // Clear any existing tree
    destroyTree(root);
    root = nullptr;
    
    // If we have a character but no question, create a single leaf node
    if (rootQuestion.empty() && !firstCharacter.empty()) {
        root = new TreeNode(firstCharacter, true, anime);
        return;
    }
    
    // Create the root question node
    root = new TreeNode(rootQuestion, false);
    
    // If we have a character, add it as a 'yes' answer
    if (!firstCharacter.empty()) {
        root->left = new TreeNode(firstCharacter, true, anime);
        // We also need a default "no" node for balance
        root->right = new TreeNode("Unknown character", true);
    } else {
        // Default children for question nodes
        root->left = new TreeNode("", false);  // Yes branch
        root->right = new TreeNode("", false); // No branch
    }
}

// Add a question node (with empty children)
void BinaryTree::addQuestion(TreeNode* node, const std::string& question) {
    if (node == nullptr) {
        std::cerr << "Error: Cannot add question to null node." << std::endl;
        return;
    }
    
    // Set up the node as a question
    node->data = question;
    node->isCharacter = false;
    
    // If children don't exist, create empty nodes for yes/no branches
    if (node->left == nullptr) {
        node->left = new TreeNode("", false);  // Yes branch
    }
    
    if (node->right == nullptr) {
        node->right = new TreeNode("", false); // No branch
    }
}

// Add a character (leaf) node at the specified position
void BinaryTree::addCharacter(TreeNode* parent, bool forYesPath, const std::string& character, const std::string& anime) {
    if (parent == nullptr) {
        std::cerr << "Error: Cannot add character to null parent." << std::endl;
        return;
    }
    
    TreeNode* newNode = new TreeNode(character, true, anime);
    
    if (forYesPath) {
        // Delete existing node if it exists
        if (parent->left != nullptr) {
            delete parent->left;
        }
        parent->left = newNode;
    } else {
        // Delete existing node if it exists
        if (parent->right != nullptr) {
            delete parent->right;
        }
        parent->right = newNode;
    }
}

// Overloaded method to add character to both positions
void BinaryTree::addCharacter(TreeNode* parent, const std::string& character, const std::string& anime) {
    if (parent == nullptr) {
        std::cerr << "Error: Cannot add character to null parent." << std::endl;
        return;
    }
    
    // Add character to both left and right if they're null
    if (parent->left == nullptr) {
        parent->left = new TreeNode(character, true, anime);
    } else if (!parent->left->isLeaf()) {
        // If it's not a leaf, we can set it to be one
        delete parent->left;
        parent->left = new TreeNode(character, true, anime);
    }
    
    if (parent->right == nullptr) {
        parent->right = new TreeNode(character, true, anime);
    } else if (!parent->right->isLeaf()) {
        // If it's not a leaf, we can set it to be one
        delete parent->right;
        parent->right = new TreeNode(character, true, anime);
    }
}

// Update a node to add a new character and question
void BinaryTree::updateNode(TreeNode* parent, TreeNode* oldNode, const std::string& newQuestion, 
                          const std::string& oldCharacter, const std::string& newCharacter,
                          const std::string& oldAnime, const std::string& newAnime, bool isNewCharacterYes) {
    if (parent == nullptr || oldNode == nullptr) {
        std::cerr << "Error: Null pointers in updateNode." << std::endl;
        return;
    }
    
    // Create a new question node
    TreeNode* questionNode = new TreeNode(newQuestion, false);
    
    // Create nodes for the characters
    TreeNode* newCharNode = new TreeNode(newCharacter, true, newAnime);
    TreeNode* oldCharNode = new TreeNode(oldCharacter, true, oldAnime);
    
    // Set up the new question node's children
    if (isNewCharacterYes) {
        questionNode->left = newCharNode;   // Yes -> new character
        questionNode->right = oldCharNode;  // No -> old character
    } else {
        questionNode->left = oldCharNode;   // Yes -> old character
        questionNode->right = newCharNode;  // No -> new character
    }
    
    // Replace the old node with the question node in the parent
    if (parent->left == oldNode) {
        parent->left = questionNode;
    } else if (parent->right == oldNode) {
        parent->right = questionNode;
    } else {
        std::cerr << "Error: Old node is not a child of parent." << std::endl;
        delete questionNode;
        delete newCharNode;
        delete oldCharNode;
        return;
    }
    
    // Delete the old node
    delete oldNode;
    
    // Add to characters list
    characters.push_back(AnimeCharacter(newCharacter, newAnime));
}

// Load characters from CSV (simplified)
bool BinaryTree::loadCharactersFromCSV(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return false;
    }
    
    characters.clear();
    std::string line;
    
    // Skip header
    std::getline(file, line);
    
    // Read data lines
    while (std::getline(file, line)) {
        std::stringstream ss(line);
        std::string token;
        std::vector<std::string> row;
        
        while (std::getline(ss, token, ',')) {
            row.push_back(token);
        }
        
        if (row.size() >= 3) {  // Character, Gender, Anime, ...
            characters.push_back(AnimeCharacter(row[0], row[2]));
        }
    }
    
    file.close();
    return true;
}

// Serialize the tree to a file
void BinaryTree::serialize(std::ofstream& outFile) {
    if (!outFile) {
        std::cerr << "Error: Invalid output file stream." << std::endl;
        return;
    }
    serializeHelper(root, outFile);
}

void BinaryTree::serializeHelper(TreeNode* node, std::ofstream& outFile) {
    if (node == nullptr) {
        // Write a marker for null nodes
        bool isNull = true;
        outFile.write(reinterpret_cast<char*>(&isNull), sizeof(bool));
        return;
    }
    
    // Write node data
    bool isNull = false;
    outFile.write(reinterpret_cast<char*>(&isNull), sizeof(bool));
    
    bool isLeaf = node->isCharacter;
    outFile.write(reinterpret_cast<char*>(&isLeaf), sizeof(bool));
    
    // Write data string
    size_t dataSize = node->data.size();
    outFile.write(reinterpret_cast<char*>(&dataSize), sizeof(size_t));
    outFile.write(node->data.c_str(), dataSize);
    
    // Write anime string for leaf nodes
    if (isLeaf) {
        size_t animeSize = node->anime.size();
        outFile.write(reinterpret_cast<char*>(&animeSize), sizeof(size_t));
        outFile.write(node->anime.c_str(), animeSize);
    }
    
    // Recursively serialize children
    serializeHelper(node->left, outFile);
    serializeHelper(node->right, outFile);
}

// Deserialize the tree from a file
void BinaryTree::deserialize(std::ifstream& inFile) {
    if (!inFile) {
        std::cerr << "Error: Invalid input file stream." << std::endl;
        return;
    }
    
    // Clear any existing tree
    destroyTree(root);
    root = nullptr;
    
    // Read the new tree
    root = deserializeHelper(inFile);
}

TreeNode* BinaryTree::deserializeHelper(std::ifstream& inFile) {
    if (!inFile) {
        std::cerr << "Error: Invalid input file stream in deserializeHelper." << std::endl;
        return nullptr;
    }
    
    // Read if the node is null
    bool isNull;
    inFile.read(reinterpret_cast<char*>(&isNull), sizeof(bool));
    
    if (isNull) {
        return nullptr;
    }
    
    // Read node data
    bool isLeaf;
    inFile.read(reinterpret_cast<char*>(&isLeaf), sizeof(bool));
    
    size_t dataSize;
    inFile.read(reinterpret_cast<char*>(&dataSize), sizeof(size_t));
    
    std::string data(dataSize, ' ');
    inFile.read(&data[0], dataSize);
    
    std::string anime;
    if (isLeaf) {
        // Read anime for leaf nodes
        size_t animeSize;
        inFile.read(reinterpret_cast<char*>(&animeSize), sizeof(size_t));
        
        anime.resize(animeSize);
        inFile.read(&anime[0], animeSize);
    }
    
    // Create the node
    TreeNode* node = new TreeNode(data, isLeaf, anime);
    
    // Recursively deserialize children
    node->left = deserializeHelper(inFile);
    node->right = deserializeHelper(inFile);
    
    return node;
}

#endif // BINARY_TREE_H 