# AnimeKinator

AnimeKinator is a simple Akinator-like guessing game for anime characters developed by Otaku Interactive Studios. The program uses binary trees to build a decision-making game that guesses anime characters through yes/no questions.

## Features

1. **Interactive UI**: Console-based interface with yes/no questions
2. **Learning System**: When the program guesses incorrectly, it learns new characters and questions
3. **Persistence**: Saves the knowledge base between sessions
4. **Character Database**: Optional loading of characters from a CSV file

## Data Structures

- **Binary Tree**: Core decision-making structure
  - Internal nodes are questions
  - Leaf nodes are characters
  - Left branches represent "Yes" answers
  - Right branches represent "No" answers

## Files

- **main.cpp**: Main program logic and user interface
- **binary_tree.h**: Binary tree implementation
- **Anime_Traits.csv**: Optional character dataset

## How to Compile

```bash
g++ -std=c++11 main.cpp -o animekinator
```

## How to Run

```bash
./animekinator
```

## How to Play

1. Think of an anime character
2. The program will ask yes/no questions about your character
3. If it guesses correctly, confirm with "yes"
4. If it guesses incorrectly:
   - Enter your character's name
   - Enter the anime they're from
   - Provide a distinguishing question
   - Tell the program the correct answer for your character

## Example Gameplay

```
Is the character male? (yes/no): yes
Is he from Naruto? (yes/no): yes

My guess is: Naruto Uzumaki
Was I correct? (yes/no): no

Oh no! Who was your character? Sasuke Uchiha
What anime is Sasuke Uchiha from? Naruto
What question would distinguish Sasuke Uchiha from Naruto Uzumaki? Does he have the Sharingan?
What is the answer for Sasuke Uchiha? (yes/no): yes

Thanks! I've added this to my knowledge.
```
# Anime-Kinator 