#include <iostream>
#include <string>
#include <fstream>
#include "binary_tree.h"

using namespace std;

// Function prototypes
void displayWelcomeMessage();
void playGame(BinaryTree& tree);
void addNewCharacter(BinaryTree& tree, TreeNode* lastNode, bool wasCorrect);
void saveTree(BinaryTree& tree, const string& filename);
BinaryTree loadTree(const string& filename);
BinaryTree createDefaultTree();

int main() {
    displayWelcomeMessage();
    
    BinaryTree animeTree;
    string dataFilename = "anime_data.bin";
    string csvFilename = "Anime_Traits.csv";
    
    // Try to load existing tree from file
    ifstream inFile(dataFilename, ios::binary);
    if (inFile.good()) {
        inFile.close();
        animeTree = loadTree(dataFilename);
        cout << "Loaded existing anime database.\n\n";
    } else {
        cout << "Creating new anime database.\n\n";
        
        // Try to load from CSV
        if (animeTree.loadCharactersFromCSV(csvFilename)) {
            cout << "Successfully loaded characters from CSV.\n";
            
            // Create a simple tree with initial questions
            string rootQuestion = "Is the character male?";
            animeTree.buildNewTree(rootQuestion, "", "");
            
            TreeNode* root = animeTree.getRoot();
            
            try {
                // Male branch
                TreeNode* maleNode = root->getLeft();
                if (maleNode == nullptr) {
                    maleNode = new TreeNode("", false);
                    root->setLeft(maleNode);
                }
                string ninjaQuestion = "Is he a ninja?";
                animeTree.addQuestion(maleNode, ninjaQuestion);
                
                // Yes to ninja - be careful with null pointers
                TreeNode* ninjaNode = maleNode->getLeft();
                if (ninjaNode) {
                    string narutoQuestion = "Is he from \"Naruto\"?";
                    animeTree.addQuestion(ninjaNode, narutoQuestion);
                    
                    // Add characters if the nodes exist
                    if (ninjaNode->getLeft()) {
                        animeTree.addCharacter(ninjaNode->getLeft(), "Naruto Uzumaki", "Naruto");
                    }
                    
                    if (ninjaNode->getRight()) {
                        animeTree.addCharacter(ninjaNode->getRight(), "Tanjiro Kamado", "Demon Slayer");
                    }
                }
                
                // No to ninja
                TreeNode* notNinjaNode = maleNode->getRight();
                if (notNinjaNode) {
                    string aoTQuestion = "Is he from \"Attack on Titan\"?";
                    animeTree.addQuestion(notNinjaNode, aoTQuestion);
                    
                    // Yes to AoT
                    TreeNode* aotNode = notNinjaNode->getLeft();
                    if (aotNode) {
                        string titanQuestion = "Does he transform into a Titan?";
                        animeTree.addQuestion(aotNode, titanQuestion);
                        
                        if (aotNode->getLeft()) {
                            animeTree.addCharacter(aotNode->getLeft(), "Eren Yeager", "Attack on Titan");
                        }
                        
                        if (aotNode->getRight()) {
                            animeTree.addCharacter(aotNode->getRight(), "Levi Ackerman", "Attack on Titan");
                        }
                    }
                    
                    // No to AoT
                    if (notNinjaNode->getRight()) {
                        animeTree.addCharacter(notNinjaNode->getRight(), "Light Yagami", "Death Note");
                    }
                }
                
                // Female branch
                TreeNode* femaleNode = root->getRight();
                if (femaleNode == nullptr) {
                    femaleNode = new TreeNode("", false);
                    root->setRight(femaleNode);
                }
                string chainsawQuestion = "Is she from \"Chainsaw Man\"?";
                animeTree.addQuestion(femaleNode, chainsawQuestion);
                
                // Yes to Chainsaw Man
                TreeNode* chainsawNode = femaleNode->getLeft();
                if (chainsawNode) {
                    string hunterQuestion = "Is she a public safety devil hunter?";
                    animeTree.addQuestion(chainsawNode, hunterQuestion);
                    
                    // Add characters if nodes exist
                    if (chainsawNode->getLeft()) {
                        animeTree.addCharacter(chainsawNode->getLeft(), "Power", "Chainsaw Man");
                    }
                    
                    if (chainsawNode->getRight()) {
                        animeTree.addCharacter(chainsawNode->getRight(), "Kobeni", "Chainsaw Man");
                    }
                }
                
                // No to Chainsaw Man
                if (femaleNode->getRight()) {
                    animeTree.addCharacter(femaleNode->getRight(), "Mikasa Ackerman", "Attack on Titan");
                }
            }
            catch (const exception& e) {
                cout << "Error building tree: " << e.what() << "\nFalling back to default tree.\n";
                animeTree = createDefaultTree();
            }
        } else {
            animeTree = createDefaultTree();
        }
    }
    
    char playAgain = 'y';
    while (tolower(playAgain) == 'y') {
        try {
            playGame(animeTree);
        }
        catch (const exception& e) {
            cout << "Error during game: " << e.what() << endl;
            break;
        }
        
        cout << "\nDo you want to play again? (yes/no): ";
        cin >> playAgain;
        cin.ignore(10000, '\n');  // Clear input buffer
    }
    
    // Save the tree before exiting
    try {
        saveTree(animeTree, dataFilename);
    }
    catch (const exception& e) {
        cout << "Error saving tree: " << e.what() << endl;
    }
    
    cout << "Thank you for using AnimeKinator! Goodbye!\n";
    
    return 0;
}

void displayWelcomeMessage() {
    cout << "========================================\n";
    cout << "Welcome to AnimeKinator by Otaku Interactive Studios!\n";
    cout << "========================================\n";
    cout << "Think of an anime character and I will try to guess it.\n\n";
}

void playGame(BinaryTree& tree) {
    if (tree.isEmpty()) {
        cout << "The database is empty. Let's add your first character!\n";
        string name;
        cout << "What character were you thinking of? ";
        getline(cin, name);
        
        string anime;
        cout << "What anime is the character from? ";
        getline(cin, anime);
        
        string question = "Is the character from \"" + anime + "\"?";
        tree.buildNewTree(question, name, anime);
        return;
    }
    
    TreeNode* current = tree.getRoot();
    TreeNode* previous = nullptr;
    bool lastAnswer = false;
    
    // Navigate the tree based on user responses
    while (current != nullptr && !current->isLeaf()) {
        cout << "Q: " << current->getData() << " (yes/no)\n> ";
        string answer;
        cin >> answer;
        cin.ignore(10000, '\n');  // Clear input buffer
        
        previous = current;
        
        // Convert answer to lowercase
        for (auto& c : answer) c = tolower(c);
        lastAnswer = (answer == "yes" || answer == "y");
        
        if (lastAnswer) {
            current = current->getLeft();  // Yes -> go left
        } else {
            current = current->getRight(); // No -> go right
        }
    }
    
    // If we've reached a leaf (character node)
    if (current != nullptr && current->isLeaf()) {
        cout << "\nMy guess is: " << current->getData() << "\n";
        cout << "Was I correct? (yes/no)\n> ";
        string answer;
        cin >> answer;
        cin.ignore(10000, '\n');  // Clear input buffer
        
        // Convert answer to lowercase
        for (auto& c : answer) c = tolower(c);
        bool wasCorrect = (answer == "yes" || answer == "y");
        
        if (wasCorrect) {
            cout << "Great! I guessed it right!\n";
        } else {
            addNewCharacter(tree, previous, lastAnswer);
        }
    } else {
        cout << "Error: Reached a null node.\n";
    }
}

void addNewCharacter(BinaryTree& tree, TreeNode* lastNode, bool wasYes) {
    string currentCharacter;
    string currentAnime = "";
    
    if (wasYes) {
        currentCharacter = lastNode->getLeft()->getData();
        currentAnime = lastNode->getLeft()->getAnime();
    } else {
        currentCharacter = lastNode->getRight()->getData();
        currentAnime = lastNode->getRight()->getAnime();
    }
    
    string newCharacter;
    cout << "Oh no! Who was your character?\n> ";
    getline(cin, newCharacter);
    
    string newAnime;
    cout << "What anime is " << newCharacter << " from?\n> ";
    getline(cin, newAnime);
    
    string newQuestion;
    cout << "What question would distinguish " << newCharacter << " from " << currentCharacter << "?\n> ";
    getline(cin, newQuestion);
    
    cout << "What is the answer for " << newCharacter << "? (yes/no)\n> ";
    string correctAnswerForNew;
    cin >> correctAnswerForNew;
    cin.ignore(10000, '\n');  // Clear input buffer
    
    // Convert answer to lowercase
    for (auto& c : correctAnswerForNew) c = tolower(c);
    bool isNewCharacterYes = (correctAnswerForNew == "yes" || correctAnswerForNew == "y");
    
    // Update the tree
    if (wasYes) {
        tree.updateNode(lastNode, lastNode->getLeft(), newQuestion, 
                        currentCharacter, newCharacter, 
                        currentAnime, newAnime, isNewCharacterYes);
    } else {
        tree.updateNode(lastNode, lastNode->getRight(), newQuestion, 
                        currentCharacter, newCharacter, 
                        currentAnime, newAnime, isNewCharacterYes);
    }
    
    cout << "Thank you! I'll remember this next time.\n";
}

void saveTree(BinaryTree& tree, const string& filename) {
    ofstream outFile(filename, ios::binary);
    if (!outFile) {
        cerr << "Error opening file for writing: " << filename << endl;
        return;
    }
    
    tree.serialize(outFile);
    outFile.close();
}

BinaryTree loadTree(const string& filename) {
    BinaryTree tree;
    ifstream inFile(filename, ios::binary);
    if (!inFile) {
        cerr << "Error opening file for reading: " << filename << endl;
        return tree;
    }
    
    tree.deserialize(inFile);
    inFile.close();
    return tree;
}

BinaryTree createDefaultTree() {
    BinaryTree tree;
    
    // Create a simple tree with initial questions
    string rootQuestion = "Is the character male?";
    tree.buildNewTree(rootQuestion, "", "");
    
    // Build a basic decision tree
    TreeNode* root = tree.getRoot();
    
    // Male branch
    TreeNode* maleNode = root->getLeft();
    string ninjaQuestion = "Is he a ninja?";
    tree.addQuestion(maleNode, ninjaQuestion);
    
    // Ninja -> Yes
    tree.addCharacter(maleNode->getLeft(), "Naruto Uzumaki", "Naruto");
    
    // Ninja -> No
    tree.addCharacter(maleNode->getRight(), "Light Yagami", "Death Note");
    
    // Female branch
    TreeNode* femaleNode = root->getRight();
    string aiQuestion = "Is she from \"Attack on Titan\"?";
    tree.addQuestion(femaleNode, aiQuestion);
    
    // AoT -> Yes
    tree.addCharacter(femaleNode->getLeft(), "Mikasa Ackerman", "Attack on Titan");
    
    // AoT -> No
    tree.addCharacter(femaleNode->getRight(), "Sailor Moon", "Sailor Moon");
    
    return tree;
} 